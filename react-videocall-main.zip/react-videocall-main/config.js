module.exports = {
  PORT: process.env.PORT || 5000
};
